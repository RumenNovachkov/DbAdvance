﻿namespace P01_HospitalDatabase.Data
{
    class Configuration
    {
        public const string ConnectionString = @"Server=.;Database=HospitalApp; Integrated Security=True";
    }
}
