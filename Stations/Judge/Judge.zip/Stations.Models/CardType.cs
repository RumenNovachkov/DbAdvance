﻿namespace Stations.Models
{
    public enum CardType
    {
        Pupil,
        Student,
        Elder,
        Debilitated,
        Normal
    }
}
