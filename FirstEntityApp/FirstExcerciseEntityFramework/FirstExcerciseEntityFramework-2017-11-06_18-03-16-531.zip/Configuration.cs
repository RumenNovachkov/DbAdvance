﻿namespace FirstExcerciseEntityFramework
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=RZR\SQLEXPRESS;Database=SoftUni;Integrated Security=True;";
    }
}
