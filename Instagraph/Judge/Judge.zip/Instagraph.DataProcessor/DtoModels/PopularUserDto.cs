﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Instagraph.DataProcessor.DtoModels
{
    public class PopularUserDto
    {
        public string Username { get; set; }
        public int Followers { get; set; }
    }
}
